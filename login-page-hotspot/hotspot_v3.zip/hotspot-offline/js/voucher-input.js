(function () {
	'use strict';
	$(".voucher-input").keyup(function () {
		if (this.value.length == this.maxLength) {
			var $next = $(this).next('.voucher-input');
			if ($next.length)
				$(this).next('.voucher-input').focus();
			else
				$(this).blur();
		}
	});
	$(':input').keydown(function(e) {
		if ((e.which == 8 || e.which == 46) && $(this).val() =='') {
			$(this).prev('input').focus();
		}
	});
})();