/*
JASA SETTING MIKROTIK
08157964251

DONASI
Mandiri 180 000 200 1677
*/

// BY PASS
// ip fir addr add address=wa.me list=BYPASS
// ip fir addr add address=api.whatsapp.com list=BYPASS
// ip fir addr add address=app.chaport.com list=BYPASS
// ip fir addr add address=server.chaport.com list=BYPASS
// ip fir addr add address=cdnjs.cloudflare.com list=BYPASS comment="DISABLE JIKA PAKE VERSI OFFLINE"
// ip fir addr add address=fonts.googleapis.com list=BYPASS  comment="DISABLE JIKA PAKE VERSI OFFLINE"
// TAMBAH DI IP HOTSPOT WALLED GARDEN IP LIST DST BYPASS


var title = "WiFi HotSpot";
var ssid = "@WiFi.io";
var wifi_url = "wifi.io"; // login URL
var whatsapp = "628157964250"; // gunakan 62

var chat_id = "60fa85aaca4af626206301fb"; // ganti sesuai dengan chat id daftar di chaport
// https://app.chaport.com/#/settings/installation_code

// aplikasi customer suppport
// https://play.google.com/store/apps/details?id=com.chaport.chaportmobile

var paket_list = [{
	"paket": "MINI",
	"harga": "Rp1000",
	"aktif": "5 Jam",
	"durasi": "3 Jam",
	"speed": "2Mbps",
	"data": "Unlimited",
	"link": "https://api.whatsapp.com/send?phone= " + whatsapp + "&text=Saya%20mau%20beli%20voucher%20MINI"
},{
	"paket": "MINOR",
	"harga": "Rp2000",
	"aktif": "10 Jam",
	"durasi": "6 Jam",
	"speed": "2Mbps",
	"data": "Unlimited",
	"link": "https://api.whatsapp.com/send?phone= " + whatsapp + "&text=Saya%20mau%20beli%20voucher%20MINOR"
},{
	"paket": "MAJOR",
	"harga": "Rp4000",
	"aktif": "20 Jam",
	"durasi": "12 Jam",
	"speed": "2Mbps",
	"data": "Unlimited",
	"link": "https://api.whatsapp.com/send?phone= " + whatsapp + "&text=Saya%20mau%20beli%20voucher%20MAJOR"
},{
	"paket": "MEGA",
	"harga": "Rp5000",
	"aktif": "36 Jam",
	"durasi": "24 Jam",
	"speed": "2Mbps",
	"data": "Unlimited",
	"link": "https://api.whatsapp.com/send?phone= " + whatsapp + "&text=Saya%20mau%20beli%20voucher%20MEGA"
}];

var pembayaran = [{
	"bank": "Bank Mandiri",
	"nomor": "180 000 200 1677",
	"nama": "Muhamad Abdul Bahrun"
},{
	"bank": "DANA",
	"nomor": "08157964251",
	"nama": "Muhamad Abdul Bahrun"
}];

$(document).ready(function() {
	document.title = title;
	$("#title").html(title);
	$("#ssid").html(ssid);
	$("[id='wifi_url']").html(wifi_url);
	$("#WhatsApp").attr("href", "https://wa.me/"+whatsapp);
	$("#LiveChat").attr("href", "https://app.chaport.com/widget/show.html?appid="+chat_id);
});