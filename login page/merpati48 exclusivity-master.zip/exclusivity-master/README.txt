TITLE: Exclusivity - Free Bootstrap 4 Template
AUTHOR: Free-Template.co
LICENSE: Under Creative Commons 3.0 (free-template.co/license)
Twitter: https://twitter.com/Free_Templateco


CREDITS:

Bootstrap
http://getbootstrap.com/

jQuery
http://jquery.com/

Google Fonts
https://www.google.com/fonts/

Icomoon
https://icomoon.io/app/

Open Iconic
https://useiconic.com/open/

Demo Images
https://unsplash.com

Waypoints
https://imakewebthings.com/waypoints/

Owl Carousel 2
https://owlcarousel2.github.io/OwlCarousel2/

AnimateNumber
aishek.github.io/jquery-animateNumber/

For More HTML5 Templates:
https://themewagon.com
